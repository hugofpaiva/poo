package aula08.Ex2;

public enum VariedadeCarne { VACA, PORCO, PERU, FRANGO, OUTRA }
