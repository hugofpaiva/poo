package aula08.Ex2;

public enum TipoPeixe { CONGELADO, FRESCO }
